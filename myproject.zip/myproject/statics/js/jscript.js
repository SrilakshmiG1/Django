function onSignIn(){
	$.ajax({
		data: JSON.stringify({ name:$('#uname').val(), password:$('#pwd').val()}),
		type:'POST',
		url:'/logedin/'})
}
function username(){
	var un=document.getElementById("uname").value;
	var reg = /^[a-zA-Z\-]+$/;
	var r1=un.match(reg);
	if(r1)
	{
		document.getElementById('span-1').innerHTML="";
		return true;
	}
	else
	{
		document.getElementById('span-1').innerHTML="**Enter a valid Username";
		document.getElementById("uname").value="";
		document.getElementById("uname").focus();
		return false;
	}
}
function validate()
{
	var pswd=/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/
	var p=document.getElementById("pwd").value;
	var res=p.match(pswd);
	if(res)
	{
		return true;
	}
	else
	{
		alert("Enter a valid  Password");
		document.getElementByID("pwd").focus();
		return false;
	}
}


	

