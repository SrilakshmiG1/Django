from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse
import json
from .models import User

# Create your views here.
def login(request):
		return render(request, "login.html")
		

@csrf_exempt
def logedin(request):
	body_unicode = request.body.decode('utf-8')
	body = json.loads(body_unicode)
	content = body['content']
	print(content)
	print(type(content))
	data=json.loads(request.body.decode('utf-8'))
	print(data)
	data = json.dumps(data) 
	print(type(data))
	obj=User()
	return HttpResponse(data, content_type= "application/json")

#csrfmiddlewaretoken: '{{ csrf_token }}'
